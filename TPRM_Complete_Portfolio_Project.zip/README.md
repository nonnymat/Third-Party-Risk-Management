# Third-Party Cybersecurity Risk Assessment & Vendor Risk Management (TPRM)

## Scenario
FinSecure Bank is evaluating **CloudPay HR**, a fictional cloud HR/payroll provider that will process sensitive employee information.

## Project objective
Demonstrate practical GRC/IT Risk capabilities across:
- Third-party risk assessment
- Security questionnaires
- Control and evidence review
- Risk scoring
- Audit-style findings
- Remediation tracking
- Executive reporting
- Power BI dashboard design

## Files
- `TPRM_Complete_Workbook.xlsx` — questionnaire, evidence review, risk register, control matrix, remediation tracker and Power BI-ready data.
- `TPRM_Executive_Report.pdf` — management-level assessment and recommendation.

## Risk methodology
Risk score = Likelihood × Impact

- 1–5: Low
- 6–10: Medium
- 11–15: High
- 16–25: Critical

## Suggested Power BI pages
1. Executive Overview
2. Risk Distribution
3. Control Assessment
4. Remediation Tracking
5. Compliance & Evidence

## Suggested CV bullet
Designed a third-party cybersecurity risk assessment for a fictional financial institution, developing a vendor security questionnaire, control/evidence review, 5×5 risk model, risk register, audit findings, remediation tracker and Power BI-ready executive reporting aligned with ISO 27001/NIST CSF concepts.

> All organizations, data, findings and dates are fictional and created for portfolio demonstration.
